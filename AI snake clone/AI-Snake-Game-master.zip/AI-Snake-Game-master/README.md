This project was an assignment for a university course in Artificial Intelligence.

The goal of the assignment was to implement a snake game that uses AI to find food and avoid obstacles.
My implementation was done in JavaScript, using canvas to draw the UI.
The algorithms used to search for the food are DFS, BFS, and A* using some heuristics.

##Demo

http://louisbourque.ca/AI-Snake-Game/